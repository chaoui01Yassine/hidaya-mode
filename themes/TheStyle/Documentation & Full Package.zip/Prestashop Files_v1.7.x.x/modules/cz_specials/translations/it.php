<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_specials}prestashop>cz_specials_8af828f302b91d1f905dc35acc43efaa'] = 'Prodotti speciali';
$_MODULE['<{cz_specials}prestashop>cz_specials_f95ceb82c51c99dc9b9e5678b291c44b'] = 'Tutti i prodotti di vendita';
