<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_featuredproducts}prestashop>cz_featuredproducts_ca7d973c26c57b69e0857e7a0332d545'] = 'منتجات مميزة';
$_MODULE['<{cz_featuredproducts}prestashop>cz_featuredproducts_40dec546414c1ebdfde8d9858f0938c3'] = 'جميع المنتجات';
