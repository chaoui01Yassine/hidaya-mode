<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_newproducts}prestashop>cz_newproducts_sidebar_9ff0635f5737513b1a6f559ac2bff745'] = 'منتجات جديدة';
$_MODULE['<{cz_newproducts}prestashop>cz_newproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'منتجات جديدة';
$_MODULE['<{cz_newproducts}prestashop>cz_newproducts_60efcc704ef1456678f77eb9ee20847b'] = 'جميع المنتجات الجديدة';
