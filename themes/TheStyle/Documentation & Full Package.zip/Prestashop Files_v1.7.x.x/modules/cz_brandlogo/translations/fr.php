<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_brandlogo}prestashop>cz_brandlogo_d38a013002c444c2bae97b1e56f7660e'] = ' Meilleures marques';
$_MODULE['<{cz_brandlogo}prestashop>cz_brandlogo_8e41eae149ff3fa38cc9c4fde945f2c3'] = ' Sans marque';
